-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: restoschema
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cooks`
--

DROP TABLE IF EXISTS `cooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cooks` (
  `UID` int NOT NULL,
  `FName` varchar(45) NOT NULL,
  `LName` varchar(45) NOT NULL,
  `Addr` varchar(60) NOT NULL,
  `City` varchar(45) NOT NULL,
  `State` char(2) NOT NULL,
  `email` varchar(45) NOT NULL,
  `PhoneNum` char(11) NOT NULL,
  PRIMARY KEY (`UID`),
  UNIQUE KEY `CookId_UNIQUE` (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cooks`
--

LOCK TABLES `cooks` WRITE;
/*!40000 ALTER TABLE `cooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host`
--

DROP TABLE IF EXISTS `host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host` (
  `UID` int NOT NULL,
  `Fname` varchar(45) NOT NULL,
  `LName` varchar(45) NOT NULL,
  `Addr` varchar(45) NOT NULL,
  `State` char(2) NOT NULL,
  `City` varchar(45) NOT NULL,
  `PhoneNum` char(11) NOT NULL,
  `email` varchar(45) NOT NULL,
  `Hostcol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  UNIQUE KEY `UID_UNIQUE` (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host`
--

LOCK TABLES `host` WRITE;
/*!40000 ALTER TABLE `host` DISABLE KEYS */;
/*!40000 ALTER TABLE `host` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `host view`
--

DROP TABLE IF EXISTS `host view`;
/*!50001 DROP VIEW IF EXISTS `host view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `host view` AS SELECT 
 1 AS `Table_ID`,
 1 AS `Capacity`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `host_has_table_table`
--

DROP TABLE IF EXISTS `host_has_table_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host_has_table_table` (
  `Host_UID` int NOT NULL,
  `Table_Table_Table_ID` decimal(10,0) unsigned NOT NULL,
  PRIMARY KEY (`Host_UID`,`Table_Table_Table_ID`),
  KEY `fk_Host_has_Table_Table_Table_Table1_idx` (`Table_Table_Table_ID`),
  KEY `fk_Host_has_Table_Table_Host1_idx` (`Host_UID`),
  CONSTRAINT `fk_Host_has_Table_Table_Host1` FOREIGN KEY (`Host_UID`) REFERENCES `host` (`UID`),
  CONSTRAINT `fk_Host_has_Table_Table_Table_Table1` FOREIGN KEY (`Table_Table_Table_ID`) REFERENCES `table_table` (`Table_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host_has_table_table`
--

LOCK TABLES `host_has_table_table` WRITE;
/*!40000 ALTER TABLE `host_has_table_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `host_has_table_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `Order_ID` int unsigned NOT NULL,
  `ItemName` varchar(45) NOT NULL,
  `Quantity` int NOT NULL,
  `Time_Ordered` time NOT NULL,
  `Order_is_Ready` tinyint NOT NULL,
  `Waiter_UID` int unsigned NOT NULL,
  `Table_Table ID` decimal(10,0) unsigned NOT NULL,
  PRIMARY KEY (`Order_ID`),
  KEY `fk_Orders_Waiter_idx` (`Waiter_UID`),
  KEY `fk_Orders_Table1_idx` (`Table_Table ID`),
  CONSTRAINT `fk_Orders_Table1` FOREIGN KEY (`Table_Table ID`) REFERENCES `table_table` (`Table_ID`),
  CONSTRAINT `fk_Orders_Waiter` FOREIGN KEY (`Waiter_UID`) REFERENCES `waiter` (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `orders view`
--

DROP TABLE IF EXISTS `orders view`;
/*!50001 DROP VIEW IF EXISTS `orders view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `orders view` AS SELECT 
 1 AS `itemName`,
 1 AS `quantity`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `orders_has_cooks`
--

DROP TABLE IF EXISTS `orders_has_cooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_has_cooks` (
  `Orders_OrderID` int unsigned NOT NULL,
  `Cooks_CookId` int NOT NULL,
  PRIMARY KEY (`Orders_OrderID`,`Cooks_CookId`),
  KEY `fk_Orders_has_Cooks_Cooks1_idx` (`Cooks_CookId`),
  KEY `fk_Orders_has_Cooks_Orders1_idx` (`Orders_OrderID`),
  CONSTRAINT `fk_Orders_has_Cooks_Cooks1` FOREIGN KEY (`Cooks_CookId`) REFERENCES `cooks` (`UID`),
  CONSTRAINT `fk_Orders_has_Cooks_Orders1` FOREIGN KEY (`Orders_OrderID`) REFERENCES `orders` (`Order_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_has_cooks`
--

LOCK TABLES `orders_has_cooks` WRITE;
/*!40000 ALTER TABLE `orders_has_cooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_has_cooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_table`
--

DROP TABLE IF EXISTS `table_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `table_table` (
  `Table_ID` decimal(10,0) unsigned NOT NULL,
  `Available` tinyint NOT NULL,
  `Capacity` int NOT NULL,
  `Waiter_UID` int unsigned NOT NULL,
  PRIMARY KEY (`Table_ID`),
  UNIQUE KEY `Table ID_UNIQUE` (`Table_ID`),
  KEY `fk_Table_Waiter1_idx` (`Waiter_UID`),
  CONSTRAINT `fk_Table_Waiter1` FOREIGN KEY (`Waiter_UID`) REFERENCES `waiter` (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_table`
--

LOCK TABLES `table_table` WRITE;
/*!40000 ALTER TABLE `table_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `table_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waiter`
--

DROP TABLE IF EXISTS `waiter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `waiter` (
  `UID` int unsigned NOT NULL,
  `Fname` varchar(30) NOT NULL,
  `LName` varchar(30) NOT NULL,
  `Addr` varchar(60) NOT NULL,
  `State` char(2) NOT NULL,
  `City` varchar(45) NOT NULL,
  `email` varchar(60) NOT NULL,
  `PhoneNum` char(11) NOT NULL,
  `Waitercol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  UNIQUE KEY `UID_UNIQUE` (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waiter`
--

LOCK TABLES `waiter` WRITE;
/*!40000 ALTER TABLE `waiter` DISABLE KEYS */;
/*!40000 ALTER TABLE `waiter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `waiter view`
--

DROP TABLE IF EXISTS `waiter view`;
/*!50001 DROP VIEW IF EXISTS `waiter view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `waiter view` AS SELECT 
 1 AS `Table_ID`,
 1 AS `ItemName`,
 1 AS `Quantity`,
 1 AS `Time_Ordered`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `host view`
--

/*!50001 DROP VIEW IF EXISTS `host view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `host view` AS select `table_table`.`Table_ID` AS `Table_ID`,`table_table`.`Capacity` AS `Capacity` from `table_table` where (`table_table`.`Available` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `orders view`
--

/*!50001 DROP VIEW IF EXISTS `orders view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `orders view` AS select `orders`.`ItemName` AS `itemName`,`orders`.`Quantity` AS `quantity` from `orders` where (`orders`.`Order_is_Ready` = 0) order by `orders`.`Time_Ordered` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `waiter view`
--

/*!50001 DROP VIEW IF EXISTS `waiter view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `waiter view` AS select `table_table`.`Table_ID` AS `Table_ID`,`orders`.`ItemName` AS `ItemName`,`orders`.`Quantity` AS `Quantity`,`orders`.`Time_Ordered` AS `Time_Ordered` from (`table_table` join `orders`) where (`orders`.`Order_is_Ready` = 0) order by `orders`.`Time_Ordered` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-29 22:23:00
